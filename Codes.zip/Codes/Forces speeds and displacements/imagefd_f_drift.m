function [lcorr,fncorr]=imagefd_f_drift(l,n,k,pullin,pullout)

%Rodrigo Bernal
%Apr. 2016

%Takes the l,n (lateral and normal displacement) vs frame number vectors
%coming out of imagefd_disp and outputs drift-corrected lateral
%displacement and normal force curves. We need the spring constant of the
%cantilever to get forces, and the pullin and pullout frame number to do
%drift correction.

%Drift correction: Linear correction, asuming that just before pull-in and
%just after pull-out  (pull-in and pull out frames) the tip is in the same
%spatial location and any difference is caused by drift
A=size(l);
numvec=(1:A(1))';

slope_l=(l(pullout)-l(pullin))/(pullout-pullin);
intercept_l=l(pullin)-slope_l*pullin;
lcorr=l-numvec*slope_l-intercept_l;

slope_n=(n(pullout)-n(pullin))/(pullout-pullin);
intercept_n=n(pullin)-slope_n*pullin;
ncorr=n-numvec*slope_n-intercept_n;

%Compute forces and plot
fncorr=ncorr*k;

figure('units','normalized','outerposition',[0 0 1 1])
subplot(2,2,1)
plot(l,'-o');
hold on
plot([0 A(1)],[0 0],':k');
xlabel('Frame number')
ylabel('Lateral movement [nm]');

subplot(2,2,2)
plot(lcorr,'-o');
hold on
plot([0 A(1)],[0 0],':k');
title ('Drift Corrected')
xlabel('Frame number')
ylabel('Lateral movement [nm]');

subplot(2,2,3)
plot(n,'-');
hold on
plot([0 A(1)],[0 0],':k');
xlabel('Frame number')
ylabel('Normal movement [nm]');

subplot(2,2,4)
plot(fncorr,'-');
hold on
plot([0 A(1)],[0 0],':k');
title ('Drift Corrected')
xlabel('Frame number')
ylabel('Normal Force [nN]');

%Save excel file with vectors
headings={'LatMov(nm)','NormMov(nm)','LatMovDriftCorr(nm)','NormalForceDriftCorr(nN)'};%Headings
xlswrite('Forces_analysis.xlsx',headings,1,'A1'); %Label rows according to filename
xlswrite('Forces_analysis.xlsx',[l n lcorr fncorr],1,'A2');




