function Metrics=imagefd_metrics(ncorr,pullin,pullout,slidebegin,slideend)

%Rodrigo Bernal
%Apr. 2016

%Extracts metrics from a drift-corrected normal force Vs. frame number curve
%Needs the vector of force ncorr, pullin and pullout frame numbers, and
%numbers of the frames when sliding begins and ends

%There are plotting commands throughout to highlight the determined points
%in plots coming from the imagefd_f_drift program, which should be open.

%order of variables is:
%[fpi,fpo,sdfp,maxf,avecontf,sdcontf,aveslidef,sdslidef]

Metrics=zeros(1,8);

%Standard deviation of pull in and pull out forces is computed as the
%standard deviation of the free deflection force, which should be zero but
%will not be due to drift and measurement errors

Metrics(3)=std(ncorr(pullout:end));

%Pull-in force is the minimum force between just before pull-in event and
%three more frames.Pull out force is the minimum just before pull out event.
[Metrics(1),location_pi]=min(ncorr(pullin:pullin+3));
location_pi=pullin+location_pi-1;
plot(location_pi,Metrics(1),'ok');
[Metrics(2),location_po]=min(ncorr(pullout-5:pullout));
location_po=pullout-5+location_po-1;
plot(location_po,Metrics(2),'or');

%Max force is maximum between pull in and pull out. Find location to use in
%the pull in and pull out.
[Metrics(4),location_max]=max(ncorr(location_pi:location_po));
location_max=location_max+location_pi-1;
plot(location_max,Metrics(4),'ob');

%Average contact force is the average of the external force when in
%contact. Sliding force is the average external force during nominal
%sliding. Std Dev computed using the same criterion.
Metrics(5)=mean(ncorr(pullin:pullout));
plot([0 length(ncorr)],[Metrics(5) Metrics(5)],'r');
Metrics(6)=std(ncorr(pullin:pullout));

Metrics(7)=mean(ncorr(slidebegin:slideend));
plot([0 length(ncorr)],[Metrics(7) Metrics(7)],':m');
plot([slidebegin slidebegin],[Metrics(2) Metrics(4)],'-k');
plot([slideend slideend],[Metrics(2) Metrics(4)],'-k');
Metrics(8)=std(ncorr(slidebegin:slideend));
string={'Drift Corrected'; 'Red: Ave. cont. Magenta: Ave. slid.';'Black lines: sliding period'; 'Black: Pull-in, Red: Pullout, Black: Maximum'};
title(string);

%Save Figure in case is needed later
saveas(gcf,'Summary.fig');
saveas(gcf,'Summary.tif')






