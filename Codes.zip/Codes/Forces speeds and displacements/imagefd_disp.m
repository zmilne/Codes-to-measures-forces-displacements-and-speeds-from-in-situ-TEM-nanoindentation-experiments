function [l,n]=imagefd_disp(excelfile,nm_px,angle)

%Rodrigo Bernal
%Apr. 2016

%Script to extract force Vs. frame# curves from images taken in the TEM of
%wear tests. The set of images must have been passed through the
%correlation algortihms; this code starts from the excel file resulting
%from those programs (excelfile). We also need the nm_px conversion factor
%for the images and the angle of rotation of the image set. n is the output
%of normal displacement and l lateral

%Extract data from excel file. The format of the file matters for the
%extraction to be correct. See imoffsetabsset2
A=xlsread(excelfile);
B=size(A);
A=A(3:B(1),[1 2]);

%Compute and plot tip trajectory and rotated trajectory
Traj=[-A(:,1) A(:,2)];
RotTraj= [Traj(:,1)*cosd(angle)+Traj(:,2)*sind(angle) -Traj(:,1)*sind(angle)+Traj(:,2)*cosd(angle)];
figure('units','normalized','outerposition',[0 0 1 1])
subplot(2,2,1);
plot(Traj(:,1),Traj(:,2),'-o');
axis equal
title('Tip trajectory [px]');
subplot(2,2,3);
plot(RotTraj(:,1),RotTraj(:,2),'-o');
axis equal
title('Rotated tip trajectory [px]');

%Compute and plot normal and lateral displacement
l=nm_px*RotTraj(:,1);
subplot(2,2,2);
plot(l,'-o');
xlabel('Frame number')
ylabel('Lateral movement [nm]');
n=nm_px*RotTraj(:,2);
subplot(2,2,4);
plot(n,'-o');
xlabel('Frame number')
ylabel('Normal movement [nm]');
