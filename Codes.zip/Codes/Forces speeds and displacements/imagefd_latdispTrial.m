function [l,n,angle]=imagefd_latdispTrial(excelfile,nm_px,slidebegin,slideend)

%Rodrigo Bernal
%Apr. 2016

%Script to extract lateral motion of the countersurface Vs. frame curves
%from images taken in the TEM of wear tests. In this particular case, the
%test is supposed to be a trial for the lateral motion, where only the
%countersurface is moving.The set of images must have been passed through
%the correlation algortihms; this code starts from the excel file resulting
%from those programs (excelfile). We also need the nm_px conversion factor
%for the images, and the number of the frames where sliding begins and ends
%(to compute the angle). n is the output of normal displacement and l
%lateral, angle is the angle of rotation needed to make the sliding motion
%perfectly horizontal i.e. the scanning angle.

%Extract data from excel file. The format of the file matters for the
%extraction to be correct. See imoffsetabsset2
A=xlsread(excelfile);
B=size(A);
A=A(3:B(1),[1 2]);

%Compute and plot tip trajectory and rotated trajectory
Traj=[-A(:,1) A(:,2)];
P=polyfit(Traj(slidebegin:slideend,1),Traj(slidebegin:slideend,2),1);
angle=atand(P(1));
RotTraj= [Traj(:,1)*cosd(angle)+Traj(:,2)*sind(angle) -Traj(:,1)*sind(angle)+Traj(:,2)*cosd(angle)];
figure('units','normalized','outerposition',[0 0 1 1])
subplot(2,2,1);
plot(Traj(:,1),Traj(:,2),'-o');
axis equal
title('Countersurface trajectory [px]');
subplot(2,2,3);
plot(RotTraj(:,1),RotTraj(:,2),'-o');
axis equal
Titl=sprintf('Rotated tip trajectory [px], Angle %f', angle);
title(Titl);

%Compute and plot normal and lateral displacement
l=nm_px*RotTraj(:,1);
subplot(2,2,2);
plot(l,'-o');
xlabel('Frame number')
ylabel('Lateral movement [nm]');
n=nm_px*RotTraj(:,2);
subplot(2,2,4);
plot(n,'-o');
xlabel('Frame number')
ylabel('Normal movement [nm]');

%Save Figure in case is needed later
saveas(gcf,'SummaryLatDispTrial.fig');
