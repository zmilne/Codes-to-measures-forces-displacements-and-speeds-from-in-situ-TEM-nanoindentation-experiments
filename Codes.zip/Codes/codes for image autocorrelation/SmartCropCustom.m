function SmartCropCustom(A,padding)
close all
%Version of SmartCrop to make case-by-case modifications if SmartCrops
%chops useful parts of images.

list=dir('*.tif');

%Reads the first image to determine original size (without padding)
imageinfo1=imfinfo(list(1).name);
Height1=imageinfo1.Height-2*padding;
Width1=imageinfo1.Width-2*padding;

%Determines top-left coordinates of useful area
xorigin=padding+min(A(:,1));
yorigin=padding+min(A(:,2));
%Determines width and height of useful area
width=(Width1+2*padding)-xorigin-(padding-max(A(:,1)))-1;
%width=Width1;
%height=(Height1+2*padding)-yorigin-(padding-max(A(:,2)))-1;
height=900;

for i = 1:numel(list)
    myimcrop(list(i).name,xorigin,yorigin,width,height)
end