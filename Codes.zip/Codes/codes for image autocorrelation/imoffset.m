function offset=imoffset(image1filename,image2filename,xmin,ymin,width,height,searchradius)
close all
%Finds the offset of image1 with respect to image2 based on a region
%defined by xmin ymin width and height

%V2: 2015. Add a constraint for the search area. searchradius is a parameter
%to define the search area in image 2. The search area is the ROI from
%image 1 symetrically enlarged by a number of pixels (searchradius). 

%V3: OCt 2015: Added a cut (crop) of the correlation (line 44) so that the
%maximum is searched only where total overlap between the two images
%exists, not on the padding that is added on the edges of the bigger image
%by the normxcorr2 function.

%V4: Jun 2016: Saves the figures at matlab figures instead of tiffs so that
%one can pick points in case extraction of maximum has to be done manually

%Reads the two images
image1=imread(image1filename);
image2=imread(image2filename);
sizesearch=size(image2);

%Crops an appropriate region of image 1
%subimage1 contains the image, rect contains the rectangle that define the
%cropping in format [xmin ymin width height]
rect=[xmin ymin width height];
subimage1=imcrop(image1,rect);

%Crops an appropriate region of image 2 subimage2 contains the image, rect
%contains the rectangle that define the cropping in format [xmin ymin width
%height] 
searchwidth=width+2*searchradius;
searchheight=height+2*searchradius;
xmin2=xmin-searchradius;
ymin2=ymin-searchradius;
if xmin2<0
    xmin2=0;
end
if ymin2<0
    ymin2=0;
end
if xmin2+searchwidth>sizesearch(1)
    searchwidth=sizesearch(1)-xmin2;
end
if ymin2+searchheight>sizesearch(2)
    searchheight=sizesearch(2)-ymin2;
end
rect2=[xmin2 ymin2 searchwidth searchheight];
subimage2=imcrop(image2,rect2);

%Determines correlation function
correlation=normxcorr2(subimage1,subimage2);

%Cuts away from correlation the padding around the real data
auxwidth=floor((width-1)/2);
auxheight=floor((height-1)/2);
correlation2=correlation(auxheight:auxheight+searchheight,auxwidth:auxwidth+searchwidth);

%Saves correlation 3D plot
SeedFilename=image2filename(1:length(image2filename)-4);
CurrFold=pwd;
% mkdir('Correlations');
% Imagename=strcat(CurrFold,'\Correlations\',SeedFilename,'_corr.fig');
% figure, surf(correlation2), shading flat
% xlabel('x');
% ylabel('y');
% view([1 0 0])
% pause (1);
% saveas(gcf,Imagename)

%Determines position of the peak

[ypeak, xpeak] = find(correlation2==max(correlation2(:)));
% xpeak=916; %Zac commented these out 1-12-16
% ypeak=325; %Zac commented these out 1-12-16
%Determines offset of image2 relative to image 1;
corr_offset=[xpeak-width ypeak-height];
rect_offset=[-xmin+xmin2-1 -ymin+ymin2-1] ;
crop_offset=[auxwidth-1 auxheight-1];
offset=corr_offset + rect_offset+crop_offset; 
xoffset=-offset(1);
yoffset=-offset(2);
offset=[xoffset yoffset]; 




