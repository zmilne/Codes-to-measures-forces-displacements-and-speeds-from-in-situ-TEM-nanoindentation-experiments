function y=imshiftset(Motion)
%IMSHIFTSET Shifts a set of images using the first file of the folder as a
%template and the Motion vector to shift the other images. The vector
%should be sorted by the name of the image


list=dir('*.tif');
y=zeros(numel(list),2);

%Pad the first image with black space around it so that shifting of other
%images can occur:
imagefilename=list(1).name; %Get Filename
impadding3(imagefilename);  %Pad
SeedFilename=imagefilename(1:length(imagefilename)-4); %Get filename of the padded image
Imagename=strcat(SeedFilename,'_padded.tif');

%Shift images using the padded image as template
for i=2:numel(list)
    imshiftdefinite(Imagename,list(i).name,Motion(i-1,1),Motion(i-1,2));
end

%Move the padded image to the directory where the shifted images are
CurrFold=pwd;
CurrPath=strcat(CurrFold,'\',Imagename);
FuturePath=strcat(CurrFold,'\Shifted');
movefile(CurrPath,FuturePath);






