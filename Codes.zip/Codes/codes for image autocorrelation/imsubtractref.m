function imagemod=imsubtractref(imagefilename,refimage)

%Get Image and Image information
image=imread(imagefilename);
imageref=imread(refimage);
max(max(image)) 
imagemod=image+max(image)-256;
imshow(imagemod)

%Saves the image in the same folder with '_padded' added to the filename
SeedFilename=imagefilename(1:length(imagefilename)-4);
Imagename=strcat(SeedFilename,'_refsub.tif');
imwrite(imagemod,Imagename,'tif');  