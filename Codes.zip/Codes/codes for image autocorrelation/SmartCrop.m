function SmartCrop(A,padding)
close all
%Batch crops automatically all the images from a shifting correlation by
%determining the useful area from the displacement vector A and the padding
%in the first image, which is symetric

list=dir('*.tif');

%Reads the first image to determine original size (without padding)
imageinfo1=imfinfo(list(1).name);
Height1=imageinfo1.Height-2*padding;
Width1=imageinfo1.Width-2*padding;

%Determines top-left coordinates of useful area
xorigin=padding+max([A(:,1); 0]);
yorigin=padding+max([A(:,2);0]);
%Determines width and height of useful area
width=(Width1+2*padding)-xorigin-padding-abs(min([A(:,1);0]))-1;
height=(Height1+2*padding)-yorigin-padding-abs(min([A(:,2);0]))-1;

for i = 1:numel(list)
    myimcrop(list(i).name,xorigin,yorigin,width,height)
end