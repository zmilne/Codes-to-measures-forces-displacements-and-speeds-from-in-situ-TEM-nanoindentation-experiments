function batchrotate(Angle)
close all

%Rodrigo Bernal
%Applies the function imrotate to all the tif images in a folder
%Apr 2016: Moves all rotated files to a subfolder

list=dir('*.tif');
mkdir('Rotated');
for i = 1:numel(list)
    imagefilename=list(i).name;
    image1=imread(imagefilename); %reads the image
    image1=imrotate(image1,Angle);
    SeedFilename=imagefilename(1:length(imagefilename)-4);
    Imagename=strcat(SeedFilename,'_rotated.tif');
    imwrite(image1,Imagename,'tif');
    CurrFold=pwd;
    CurrPath=strcat(CurrFold,'\',Imagename);
    FuturePath=strcat(CurrFold,'\Rotated');
    movefile(CurrPath,FuturePath);
end