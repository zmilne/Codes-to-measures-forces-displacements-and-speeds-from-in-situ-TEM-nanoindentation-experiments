function y=imoffsetabsset2(xmin,ymin,width,height,searcharea)
%IMOFFSETABSSET Absolute correlation for a set of images
%   Correlates image1 with image 2, image 1 with image 3, image 1 with 4
%   and so on based on an initial subset f pixels defined by xmin ymin
%   width and height. 

%V2: 2015. Add a constraint for the search area. searcharea is a parameter
%to define the search area in image 2. The search area is the ROI from
%image 1 symetrically enlarged by a factor (searcharea). 

%V3: Add saving of the first image with overlapped ROI to have a record. 

list=dir('*.tif');
y=zeros(numel(list),2);


for i=2:numel(list)
    disp=imoffset(list(1).name,list(i).name,xmin,ymin,width,height,searcharea);
    fprintf('imoffset(%s%s%s,%s%s%s,%d,%d,%d,%d,%d)\n',char(39),list(1).name,char(39),char(39),list(i).name,char(39),xmin,ymin,width,height,searcharea);
    y(i,1:2)=[disp(1) disp(2)];
  
end

for i=1:numel(list)
    rowlabels{i,1}=list(i).name;
end
xlswrite('Results.xlsx',rowlabels,1,'A3'); %Label rows according to filename
xlswrite('Results.xlsx',{'ROI'},1,'A1');
xlswrite('Results.xlsx',[xmin ymin width height searcharea],1,'B1');
headings={'file','x','y'};%Headings
xlswrite('Results.xlsx',headings,1,'A2'); %Label rows according to filename
xlswrite('Results.xlsx',y,1,'B3');

%Saves an image with the ROI in a separate folder. If a previous
%correlation has been run, it adds the ROI in the previous image. That way,
%we can know visually what ROI's have been tried.
CurrFold=pwd;
if 0==exist ('ROIImage', 'dir')
    mkdir('ROIImage');
    image1=imread(list(1).name);
    im=figure;
    imshow(image1,'border','tight');
    hold on
    rectangle ('Position',[xmin ymin width height]);
    frm=getframe(im);
    Imagename=strcat(CurrFold,'\ROIImage\','ROI.tif');
    imwrite(frm.cdata,Imagename)
else
    image1=imread('ROIImage\ROI.tif');
    im=figure;
    imshow(image1,'border','tight');
    hold on
    rectangle ('Position',[xmin ymin width height]);
    frm=getframe(im);
    Imagename=strcat(CurrFold,'\ROIImage\','ROI.tif');
    imwrite(frm.cdata,Imagename)
end


