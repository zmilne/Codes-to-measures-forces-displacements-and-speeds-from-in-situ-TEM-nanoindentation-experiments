function myimcrop(imagefilename,xmin,ymin,width,height)
close all
%crops an image using the defined parameters


%Reads the image
image1=imread(imagefilename);

%Crops the image
rect=[xmin ymin width height];
image1=imcrop(image1, rect);

%Saves the image in a new folder with '_cropped' added to the filename
SeedFilename=imagefilename(1:length(imagefilename)-4);
CurrFold=pwd;
mkdir('Cropped');
Imagename=strcat(CurrFold,'\Cropped\',SeedFilename,'_cropped.tif');
imwrite(image1,Imagename,'tif');



