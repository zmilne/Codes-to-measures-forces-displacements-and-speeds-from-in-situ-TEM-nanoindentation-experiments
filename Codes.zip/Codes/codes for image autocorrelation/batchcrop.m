function batchcrop(xmin,ymin,width,height)
close all
%Applies the function myimcrop to all the tif images in a folder

list=dir('*.tif');
for i = 1:numel(list)
    myimcrop(list(i).name,xmin,ymin,width,height)
end