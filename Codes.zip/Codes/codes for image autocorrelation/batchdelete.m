function batchdelete(filetype,freq)

%Deletes a certain filetype from the folder this script is run in, leaving
%only one file every 'freq' files, as sorted by name. For example:
%batchdelete('*.tif',10) would delete all tif files in the directory, except
%the first, the eleventh, the 21st, etc, of a list ordered alphabetically.

list=dir(filetype);

for i = 2:numel(list)
    if mod((i-1),freq)~=0
        delete (list(i).name);
    end
end