function imageshifted=imshiftdefinite(image1filename,image2filename,x,y)
close all
%Shifts image2 a given amount and writes it in a template (background)
%defined by image1


%Reads the two images
image1=imread(image1filename);
image2=imread(image2filename);

imageinfo2=imfinfo(image2filename);
imageinfo1=imfinfo(image1filename);

Height1=imageinfo1.Height;
Width1=imageinfo1.Width;
Height2=imageinfo2.Height;
Width2=imageinfo2.Width;

%Calculates size of padding in image 1
padx=round((Width1-Width2)/2)
pady=round((Height1-Height2)/2);

%Writes image 2 shifted by the appropriate amount to coincide with image 1
imageshifted= uint8(zeros(size(image1))); 
imageshifted(pady+y:pady+y+Height2-1,padx+x:padx+x+Width2-1)=image2; 

%Saves the image in the same folder with '_shifted' added to the filename
SeedFilename=image2filename(1:length(image2filename)-4);
CurrFold=pwd;
mkdir('Shifted');
Imagename=strcat(CurrFold,'\Shifted\',SeedFilename,'_shifted.tif');
imwrite(imageshifted,Imagename,'tif'); 



