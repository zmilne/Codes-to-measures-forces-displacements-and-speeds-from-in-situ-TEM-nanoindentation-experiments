function imagemod=impadding3(imagefilename)

%Pads the image defined in imagefilename. i.e. creates a zero image of the size
%of the image in filename adding half the height of the image in each dimension


%Get Image and Image information
image=imread(imagefilename);
imageinfo=imfinfo(imagefilename);

%Creates a blank image of the size of image multiplied by paddingfactor
newheight=round(imageinfo.Height*(1+1.0));
newwidth=round(imageinfo.Width+imageinfo.Height*1.0);

imagemod=uint8(zeros(newheight,newwidth));


%Puts the original image overlayed over the blank banckground
initialpointx=round((newwidth-imageinfo.Width)/2);
initialpointy=round((newheight-imageinfo.Height)/2);
imagemod(initialpointy:initialpointy+imageinfo.Height-1,initialpointx:initialpointx+imageinfo.Width-1)=image;
imshow(imagemod);

%Saves the image in the same folder with '_padded' added to the filename
SeedFilename=imagefilename(1:length(imagefilename)-4);
Imagename=strcat(SeedFilename,'_padded.tif');
imwrite(imagemod,Imagename,'tif');  