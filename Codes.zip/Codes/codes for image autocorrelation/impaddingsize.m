function imagemod=impaddingsize(imagefilename,width,height)

%Rodrigo Bernal Sep 2016
%Pads the image defined in imagefilename. i.e. adds zeros to make the image
%a certain size. THe padding is done keeping the original image in the top
%left corner.


%Get Image and Image information
image=imread(imagefilename);
imageinfo=imfinfo(imagefilename);

%Creates a blank image of the size of image multiplied by paddingfactor
newheight=height;
newwidth=width;

imagemod=uint8(zeros(newheight,newwidth));


%Puts the original image overlayed over the blank banckground
initialpointx=1;
initialpointy=1;
imagemod(initialpointy:initialpointy+imageinfo.Height-1,initialpointx:initialpointx+imageinfo.Width-1)=image;
imshow(imagemod);

%Saves the image in the same folder with '_padded' added to the filename
SeedFilename=imagefilename(1:length(imagefilename)-4);
Imagename=strcat(SeedFilename,'_padded.tif');
imwrite(imagemod,Imagename,'tif');  